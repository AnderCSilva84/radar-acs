'use strict';
const { getBriefingPlayback } = require('./playback');
const timeZone = 'America/Belem';
function currentDate(now = new Date()) {
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
    const value = type => parts.find(part => part.type === type).value;
    return value('year') + '-' + value('month') + '-' + value('day');
}
function fullDate(date) {
    return new Intl.DateTimeFormat('pt-BR', { timeZone, weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(date + 'T12:00:00Z'));
}
function dailyPlayback(briefing, prefix = '', now = new Date()) {
    const today = currentDate(now);
    const current = briefing.data === today;
    const introduction = current
        ? 'Bom dia, Anderson! Este é o seu Radar ACS desta ' + fullDate(today) + '. Aqui em Belém, vamos aos assuntos que você precisa saber hoje.'
        : 'Bom dia, Anderson. A edição de hoje do Radar ACS ainda não foi publicada. A última edição disponível é de ' + fullDate(briefing.data) + '. Vamos ouvir essa edição.';
    const weekday = new Intl.DateTimeFormat('pt-BR', { timeZone, weekday: 'long' }).format(now);
    const ending = current
        ? 'E esse foi o seu Radar ACS de hoje, Anderson. Tenha um ótimo ' + weekday + '. Até amanhã!'
        : 'Essa foi a última edição disponível, Anderson. Até mais!';
    return getBriefingPlayback(briefing, prefix, { introduction, ending });
}
module.exports = { currentDate, fullDate, dailyPlayback };
